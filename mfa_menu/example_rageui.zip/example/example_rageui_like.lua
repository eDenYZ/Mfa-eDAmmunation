local test = Menu:createMenu("Mon titre", "Sous titre 1", "mfa_banniere.jpg", nil, nil, nil, true, false)
local SubmenuTest = Menu:createMenu("Mon titre Sub", "Sous titre 2", "mfa_banniere.jpg", test)
local t = false

function test:menu()
    test:separator("Mon Separator", nil, false, true)
    test:button("Mon button standard", "", "Ma description", "Mon rightlabel", "", function(Hovered, Selected)
        if Hovered then
            print("Je suis sur mon button")
        end
        if (Selected) then
            print("J'ai cliqué sur mon button")
        end
    end)
    test:button("Mon button Submenu", "", "Ma description", "Mon rightlabel", nil, function(Hovered, Selected)
        if Hovered then
            print("Je suis sur mon button")
        end
        if (Selected) then
            print("J'ai cliqué sur mon button")
        end
    end, SubmenuTest, false)
    test:listbox("Ma listbox", "", "Ma description", {"Absolute", "JustGod", "Et l'autre"}, function(Hovered, Selected, onChange, index)
        if Selected then
            if index == "Absolute" then
                print("Il sais pas dev")
            elseif index == "JustGod" then
                print("C'est un beau gosse")
            elseif index == "Et l'autre" then
                print("C'est JL Power askip")
            end
        end
    end)
    test:checkbox("Ma checkbox", "", "Ma description", t, function(Hovered, Selected, val)
        if Selected then
            if val then
                t = val
                test:reload()
                print("Checked")
                return
            else
                t = val
                test:reload()
                print("UnChecked")
                return
            end
        end
    end)
    if t then 
        test:separator()
    end
    test:input("Mon input", "", "", "text", function(Hovered, Selected, inputCallback)
        if Selected then
            print("J'ai écrit: "..inputCallback)
            test:changeDesc("J'ai écrit: "..inputCallback, true)
            test:menu() --Je rappel ma fonction pour rafraichir le menu
        end
    end)
    test:button("Mon button Keyboard input", "", "Ma description", "Mon rightlabel", "", function(Hovered, Selected)
        if Hovered then
            print("Je suis sur mon button")
        end
        if (Selected) then
            local montext = Menu.KeyboardInput("Ecrire du text", "", "", 10)
            test:changeDesc("J'ai écrit: "..montext, true)
            print("J'ai cliqué sur mon button")
        end
    end)
    test:progressbar("Ma progress bar", "", "Ma description", true, 0, 10, 100, function(Hovered, Selected, onChange,ActualValue)
        if Selected then
            print("Valeur actuel: "..ActualValue)
            test:changeDesc("Valeur actuel: "..ActualValue, true)
        end
    end)
    if IsPedInAnyVehicle(PlayerPedId(), false) then
        refreshVehicleState()
        test:separator("Je suis en véhicule")
    end
end

function SubmenuTest:menu()
    SubmenuTest:clearMenuItem(0)
    SubmenuTest:separator("Mon Separator Sous Menu")
    SubmenuTest:button("Mon button standard", "", "Ma descritption Sous Menu", "Mon rightlabel", "", function(Hovered, Selected)
        if Hovered then
            print("Je suis sur mon button")
        end
        if Selected then
            print("J'ai cliqué sur mon button")
        end
    end)
end

AddEventHandler("gameEventTriggered", function(name)
    if name == "CEventNetworkPlayerEnteredVehicle" then
        test:isVisible(function(visible)
            if visible then
                test:reload()
            end
        end)
    end
end)

function refreshVehicleState()
    CreateThread(function()
        while true do
         Wait(250)
         if not IsPedInAnyVehicle(PlayerPedId(), false) then
             test:reload()
             break  
         end
        end
     end)
end


--Ouvrir le menu sans pouvoir le fermer avec la même commande
test:registerCommand("tesstt", function(args)
    test:openMenu()
    print(args)
end)

--Ouvrir le menu et le fermer avec la même touche
test:keyMap("i", "Ouvrir le menu test MFA Concept", function()
    Menu.ShowAdvancedNotification(nil, nil, "J'ai ouvert mon menu ")
end, function()
    Menu.ShowAdvancedNotification(nil, nil, "J'ai fermer mon menu ")
end)
